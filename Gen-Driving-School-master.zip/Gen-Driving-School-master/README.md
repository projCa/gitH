# Gen-Driving-School

It's a driving school system that enables a user to add a new student who is registered to that driving school.
You can add users

download the zip file then upload it in your local server 
use dbase.sql as the database
username: Bunduki
password: 0000 
