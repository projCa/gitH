
<?php
include "header.php";
?>
<p>Genesis driving school is an up and coming training institution majoring in enhancement of practical skills in driving.
With just the one branch having a fleet of vehicles in Vihiga county, Genesis ensures reliable service delivery to the people of Maseno.</p>
<p>Our main agenda is to deliver the required professional driving skills set to Kenyans, with an aim of reducing road carnage.
Imperatively, we have been promoting road safety agenda in Kenya through our individual /corporate training and campaigns initiatives for a couple of years and empowering many young Kenyans.
To be precise every year we successfully organize a country wide sensitization events on road safety like road safety campaigns, in partnership with NTSA and different household names.</p>

<h4>Accreditation</h4>
<p>Genesis driving school is fully accredited by the government of Kenya through NTSA. All our instructors are fully trained and certified NTSA. (Kindly Visit the NTSA website).</p>

<h4>Why new curriculum.</h4>
<p>The government of Kenya though the national transport and safety authority (NTSA) in its commitment to enhance road safety has introduced a more clear, concise and professional curriculum for all drivers and riders.

Genesis driving school is a highly dedicated specialist company that cares about making a difference. Since our commencement, we have trained and added value to over a thousand young Kenyans.</p>
<?php
    include "footer.php";
	?>