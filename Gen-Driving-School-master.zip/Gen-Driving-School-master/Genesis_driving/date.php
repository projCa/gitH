<?php 
echo date('l,dS F, Y');
?>