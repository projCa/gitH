<div class="footer">
		&copy; <?php echo date('Y')." "; ?>Year 3 Project
	</div>