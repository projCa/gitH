<?php
include "header.php";
?>
<div align="center">
<h3>CONTACT US</h3>
<h4>Project Developers</h4>
<p>Maseno University, Maseno<br>
Tel: 0796 14 46 08 Solomon Kamau<br>
Tel: 0703 25 43 12 Sos Peter Nyaga<br>
Email: kkingsolomon97@gmail.com<br>
sospeternyaga@gmail.com</p><br>
</div>
<?php
    include "footer.php";
	?>
