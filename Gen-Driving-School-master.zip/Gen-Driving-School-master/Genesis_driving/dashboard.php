<button class="dropdown-btn">Dashboard
				<i class="fa fa-caret-down"></i>
			</button>
			<div class="dropdown_container">
				<a href="login.php">log in as admin</a>
                <a href="userlogin.php">standard login</a>
            </div>
